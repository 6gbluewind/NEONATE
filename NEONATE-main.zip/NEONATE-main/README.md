# NEONATE：A Binary Search Strategy on Non-overlapping Pattern Matching with Gap Constraint

## Abstract
Pattern matching, or the query operation of the target sequences, is the primary task in information retrieval. Not only exploited in calculating the support or the number of pattern occurrences in knowledge mining, but it also has derived kinds of constraints during the search process. Among the assortment of matching constraints, past research has conferred a significant non-overlapping condition, which refers to any two occurrences that cannot use the same character of the sequence at the equivalent position of the pattern. Although the corresponding completeness proving has been given in the state-of-the-art works, there is still room to improve the calculating efficiency of matching under the non-overlapping constraint. Illuminated by the literature in strict matching under the non-overlapping condition, this study proposed an approach to match the given patterns, named NEONATE. Based on the Nettree index structure, we adopt a binary search strategy and pruning operation to realize the non-overlapping pattern matching under the gap and length constraints. This algorithm first locates the horizontal layer with the fewest available nodes in the Nettree. Then we need to iteratively seek the rightmost parent and rightmost child node until obtaining an occurrence that the nodes in the Nettree path can strictly satisfy the pattern constraint. We have shown the NEONATE completeness and analyzed the algorithm complexities. Both the correctness and efficiency of NEONATE have been proven in extensive experimental outcomes.

## Datasets
[dataset] (https://github.com/6gbluewind/NEONATE/blob/main/dataset.zip)

## Algorithm
[NEONATE] (https://github.com/6gbluewind/NEONATE/blob/main/NEONATE.zip)

### 中文摘要：
模式匹配，又称目标序列的查询操作是信息检索中的主要任务。它不仅可以用于计算知识挖掘中的支持或模式出现次数，在搜索过程中还具有衍生的约束类型。在各种匹配约束中，之前的研究已经将无重叠条件作为匹配的约束条件，即任何两个事件不能在模式的等效位置使用序列的相同字符。虽然现有工作已经完成了相应的完备性证明，但在无重叠约束下，模式匹配的计算效率仍有提高空间。在已有的无重叠条件下严格匹配的启发下，本研究提出了一种名为NEONATE的模式匹配方法。NEONATE将网树作为索引结构，采用二叉搜索策略和修剪操作，从而实现间隙和长度约束下的无重叠模式匹配。NEONATE算法首先找到 Nettree 中可用节点数最少的层，然后迭代地寻找最右边的父节点和最右边的子节点，直到得到 Nettree 路径中的节点可以严格满足模式约束的occurrence。我们证明了NEONATE的完备性并分析了它时间和空间复杂度。同时，NEONATE算法的准确性和有效性也在实验中得到证明。
